from datetime import datetime
from django.shortcuts import render,redirect
from . import models

# Pelanggan
def pelanggan(request) :
    allpelangganobj = models.pelanggan.objects.all()
    return render(request, 'tablepelanggan.html' , {
        "allpelangganobj" : allpelangganobj
    })

def createdatapelanggan(request) :
    if request.method == 'GET' :
        return render(request, 'formpelanggan.html')
    else :
        idpelanggan = request.POST['idpelanggan']
        nama = request.POST['nama']
        jeniskelamin = request.POST['jeniskelamin']
        nohandphone = request.POST['nohandphone']
        alamat = request.POST['alamat']

        newpelanggan = models.pelanggan(
            idpelanggan = idpelanggan,
            nama = nama,
            jeniskelamin = jeniskelamin,
            nohandphone = nohandphone,
            alamat = alamat
        )
        newpelanggan.save()
        return redirect('pelanggan')

def updatepelanggan(request,id):
    pelangganobj = models.pelanggan.objects.get(idpelanggan=id)
    if request.method == "GET":
        return render(request,'fupelanggan.html', {
            'pelangganobj' : pelangganobj,
        })
    else:
        pelangganobj.nama = request.POST['nama']    
        pelangganobj.jeniskelamin = request.POST['jeniskelamin']  
        pelangganobj.alamat = request.POST['alamat']
        pelangganobj.nohandphone = request.POST['nohandphone']
        pelangganobj.save()
        return redirect('pelanggan')

def deletepelanggan(request,id):
    pelangganobj = models.pelanggan.objects.get(idpelanggan=id)
    pelangganobj.delete()
    return redirect('pelanggan')

# Charge
def charge(request) :
    allchargeobj = models.charge.objects.all()

    return render(request, 'tablecharge.html' , {
        "allchargeobj" : allchargeobj
    })

def createdatacharge(request) :
    if request.method == 'GET' :
        return render(request, 'formcharge.html')
    else :
        rinciancharge = request.POST['rinciancharge']
        jenischarge = request.POST['jenischarge']
        hargacharge = request.POST['hargacharge']

        newcharge = models.charge(
            rinciancharge = rinciancharge,
            jenischarge = jenischarge,
            hargacharge = hargacharge,
            
        ).save()
        return redirect('charge')

def updatecharge(request,id):
    chargeobj = models.charge.objects.get(idcharge=id)
    if request.method == "GET":
        return render(request,'fucharge.html', {
            'allchargeobj' : chargeobj,
        })
    else:
        chargeobj.rinciancharge = request.POST['rinciancharge']
        chargeobj.jenischarge = request.POST['jenischarge']
        chargeobj.hargacharge = request.POST['hargacharge']
        chargeobj.save()
        return redirect('charge')

def deletecharge(request,id):
    chargeobj = models.charge.objects.get(idcharge=id)
    chargeobj.delete()
    return redirect('charge')

# Owner
def owner(request) :
    allownerobj = models.owner.objects.all()

    return render(request, 'tableowner.html' , {
        "allownerobj" : allownerobj
    })

def createdataowner(request) :
    if request.method == 'GET' :
        return render(request, 'formowner.html')
    else :
        nama = request.POST['nama']
        jeniskelamin = request.POST['jeniskelamin']
        nohandphone = request.POST['nohandphone']
        alamat = request.POST['alamat']

        newowner = models.owner(
            nama = nama,
            jeniskelamin = jeniskelamin,
            nohandphone = nohandphone,
            alamat = alamat,
            
        ).save()
        return redirect('owner')

def updateowner(request,id):
    ownerobj = models.owner.objects.get(idowner=id)
    if request.method == "GET":
        return render(request,'fuowner.html', {
            'allowner' : ownerobj,
        })
    else:
        ownerobj.idowner = request.POST['idowner']
        ownerobj.nama = request.POST['nama']
        ownerobj.jeniskelamin = request.POST['jeniskelamin']
        ownerobj.nohp = request.POST['nohandphone']
        ownerobj.alamat = request.POST['alamat']
        ownerobj.save()
        return redirect('owner')

def deleteowner(request,id):
    ownerobj = models.owner.objects.get(idowner=id)
    ownerobj.delete()
    return redirect('owner')

# Pakaian
def pakaian(request) :
    allpakaianobj = models.pakaian.objects.all()

    return render(request, 'tablepakaian.html' , {
        "allpakaianobj" : allpakaianobj
    })

def createdatapakaian(request) :
    if request.method == 'GET' :
        return render(request, 'formpakaian.html')
    else :
        jenispakaian = request.POST['jenispakaian']
        ukuranpakaian = request.POST['ukuranpakaian']
        hargapakaian = request.POST['hargapakaian']
        konfirmasipakaian = request.POST['konfirmasipakaian']

        newpakaian = models.pakaian(
            jenispakaian = jenispakaian,
            ukuranpakaian = ukuranpakaian,
            hargapakaian = hargapakaian,
            konfirmasipakaian = konfirmasipakaian)
        newpakaian.save()
        return redirect('pakaian')

def updatepakaian(request,id):
    pakaianobj = models.pakaian.objects.get(idpakaian=id)
    if request.method == "GET":
        return render(request,'fupakaian.html', {
            'pakaianobj' : pakaianobj,
        })
    else:
        pakaianobj.jenispakaian = request.POST['jenispakaian']
        pakaianobj.ukuranpakaian = request.POST['ukuranpakaian']
        pakaianobj.hargapakaian = request.POST['hargapakaian']
        if request.POST['konfirmasipakaian'] == "iya":
            pakaianobj.konfirmasipakaian = True
        else:
            pakaianobj.konfirmasipakaian = True
        pakaianobj.save()
        return redirect('pakaian')

def deletepakaian(request,id):
    pakaianobj = models.pakaian.objects.get(idpakaian=id)
    pakaianobj.delete()
    return redirect('pakaian')

# Peminjaman
def peminjaman(request):
    allpeminjamanobj = models.peminjaman.objects.all()
    return render (request, 'tablepeminjaman.html', {
        'allpeminjamanobj' : allpeminjamanobj,
    })

def createdatapeminjaman(request):
    if request.method == "GET":
        allpakaianobj = models.pakaian.objects.all()
        allpelangganobj = models.pelanggan.objects.all()
        allownerobj = models.owner.objects.all()
        return render(request,'formpeminjaman.html', {
            'allpakaianobj' : allpakaianobj,
            'allpelangganobj' :allpelangganobj,
            'allownerobj' : allownerobj
        })
    else:
        getpakaian = models.pakaian.objects.get(idpakaian = request.POST['idpakaian'])
        getpelanggan = models.pelanggan.objects.get(idpelanggan = request.POST['idpelanggan'])
        getowner = models.owner.objects.get(idowner = request.POST['idowner'])
        tanggalsewa = request.POST['tanggalsewa']
        lamasewa = request.POST['lamasewa']
        tanggalkembali = request.POST['tanggalkembali']
        statuspeminjaman = request.POST.get('statuspeminjaman')

        newpeminjaman = models.peminjaman(
            idpakaian = getpakaian,
            idpelanggan = getpelanggan,
            idowner = getowner,
            tanggalsewa = tanggalsewa,
            lamasewa = lamasewa,
            tanggalkembali = tanggalkembali,
            statuspeminjaman = statuspeminjaman,
        )
        newpeminjaman.save()
        return redirect('peminjaman')

def updatepeminjaman(request,id):
    peminjamanobj = models.peminjaman.objects.get(idpeminjaman=id)
    allpelangganobj = models.pelanggan.objects.all()
    allpakaianobj = models.pakaian.objects.all()
    allownerobj = models.owner.objects.all()
    tanggalsewa = datetime.strftime(peminjamanobj.tanggalsewa, '%Y-%m-%d')
    tanggalkembali = datetime.strftime(peminjamanobj.tanggalkembali, '%Y-%m-%d')
    if request.method == "GET":
        return render(request,'fupeminjaman.html', {
            'peminjamanobj' : peminjamanobj,
            'allpelangganobj': allpelangganobj,
            'allpakaianobj': allpakaianobj,
            'allownerobj': allownerobj,
            'tanggalsewa' : tanggalsewa,
            'tanggalkembali' : tanggalkembali,
        })
    else:
        getidpelanggan = models.pelanggan.objects.get(idpelanggan = request.POST['idpelanggan'])
        getidpakaian = models.pakaian.objects.get(idpakaian = request.POST['idpakaian'])
        getidowner = models.owner.objects.get(idowner = request.POST['idowner'])
        peminjamanobj.idpelanggan =getidpelanggan
        peminjamanobj.idpakaian =getidpakaian
        peminjamanobj.idowner =getidowner
        peminjamanobj.tanggalsewa = request.POST['tanggalsewa']
        peminjamanobj.statuspeminjaman = request.POST['statuspeminjaman']
        peminjamanobj.lamasewa = request.POST['lamasewa']
        peminjamanobj.tanggalkembali = request.POST['tanggalkembali']
        peminjamanobj.save()
        return redirect('peminjaman')

def deletepeminjaman(request,id):
    peminjamanobj = models.peminjaman.objects.get(idpeminjaman=id)
    peminjamanobj.delete()
    return redirect('peminjaman')

# Detail Charge
def detailcharge(request):
    detailchargeobj = models.detailcharge.objects.all()
    return render (request, 'tabledetailcharge.html', {
        'alldetailchargeobj' : detailchargeobj,
    })

def createdatadetailcharge(request):
    if request.method == "GET":
        allpeminjamanobj = models.peminjaman.objects.all()
        allchargeobj = models.charge.objects.all()
        return render(request,'formdetailcharge.html', {
            'allpeminjamanobj' : allpeminjamanobj,
            'allchargeobj' : allchargeobj
        })
    else:
        getpeminjaman = models.peminjaman.objects.get(idpeminjaman = request.POST['idpeminjaman'])
        getcharge = models.charge.objects.get(idcharge = request.POST['idcharge'] )
        jumlahitemcharge = request.POST['jumlahitemcharge']

        newdetailcharge = models.detailcharge(
            idpeminjaman = getpeminjaman,
            idcharge = getcharge,
            jumlahitemcharge = jumlahitemcharge,
        )
        newdetailcharge.save()
        return redirect('detailcharge')

def updatedetailcharge(request,id):
    detailchargeobj = models.detailcharge.objects.get(iddetailcharge=id)
    allpeminjamanobj = models.peminjaman.objects.all()
    allchargeobj = models.charge.objects.all()
    if request.method == "GET":
        return render(request,'fudetailcharge.html', {
            'detailchargeobj' : detailchargeobj,
            'allpeminjamanobj' : allpeminjamanobj,
            'allchargeobj' : allchargeobj,
        })
    else:
        getidpeminjaman = models.peminjaman.objects.get(idpeminjaman = request.POST['idpeminjaman'])
        getidcharge = models.charge.objects.get(idcharge = request.POST['idcharge'])
        detailchargeobj.idpeminjaman = getidpeminjaman
        detailchargeobj.idcharge = getidcharge
        detailchargeobj.jumlahitemcharge = request.POST['jumlahitemcharge']
        detailchargeobj.save()
        return redirect('detailcharge')

def deletedetailcharge(request,id):
    peminjamanobj = models.detailcharge.objects.get(iddetailcharge=id)
    peminjamanobj.delete()
    return redirect('detailcharge')

def dashboard(request):
    pelanggan = models.pelanggan.objects.all()
    owner = models.owner.objects.all()
    pakaian = models.pakaian.objects.all()
    peminjaman = models.peminjaman.objects.all()
    charge = models.charge.objects.all()
    detailcharge = models.detailcharge.objects.all()
    return render(request, 'index.html',{
        'pelanggan': pelanggan,
        'owner' : owner,
        'pakaian' : pakaian,
        'peminjaman' : peminjaman,
        'charge' : charge,
        'detailcharge' : detailcharge
    })

